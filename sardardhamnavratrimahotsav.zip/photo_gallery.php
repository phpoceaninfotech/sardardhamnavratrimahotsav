<?php require 'header.php'; ?>
<section>
    <div class="block gray half-parallax blackish remove-bottom">
        <div style="background:url(images/parallax8.jpg);" class="parallax"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8">
                    <div class="page-title">
                        <h1>Photo <span>Gallery</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="block gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="row">
                        <ul id="Grid">
                            <li class="mix category_1 col-md-4">
                                <div class="portfolio">
                                    <img src="admin/image/de9ee6cfd8628890243219a3bbcfbc85photo_01.jpg" alt=""/>
                                    <div class="hover">
                                        <a data-rel="prettyPhoto" href="admin/image/de9ee6cfd8628890243219a3bbcfbc85photo_01.jpg" title="">
                                            <img src="images/zoom.png" alt=""/>
                                        </a>
                                    </div>
                                </div>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <div class="portfolio">
                                    <img src="admin/image/b8b6bd3386b98181b64a8f47e5c9e5b0photo_02.jpg" alt=""/>
                                    <div class="hover">
                                        <a data-rel="prettyPhoto" href="admin/image/b8b6bd3386b98181b64a8f47e5c9e5b0photo_02.jpg" title="">
                                            <img src="images/zoom.png" alt=""/>
                                        </a>
                                    </div>
                                </div>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <div class="portfolio">
                                    <img src="admin/image/5e9338b133fbcc1907f5cad9e3bcb0e6photo_03.jpg" alt=""/>
                                    <div class="hover">
                                        <a data-rel="prettyPhoto" href="admin/image/5e9338b133fbcc1907f5cad9e3bcb0e6photo_03.jpg" title="">
                                            <img src="images/zoom.png" alt=""/></a>
                                    </div>
                                </div>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <div class="portfolio">
                                    <img src="admin/image/89a41a802e2175c57be7a6db44c1ce34photo_04.jpg" alt=""/>
                                    <div class="hover">
                                        <a data-rel="prettyPhoto" href="admin/image/89a41a802e2175c57be7a6db44c1ce34photo_04.jpg" title="">
                                            <img src="images/zoom.png" alt=""/>
                                        </a>
                                    </div>
                                </div>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <div class="portfolio">
                                    <img src="admin/image/43c9157e9891dfe292fadb1d4b8e12bcphoto_05.jpg" alt=""/>
                                    <div class="hover">
                                        <a data-rel="prettyPhoto" href="admin/image/43c9157e9891dfe292fadb1d4b8e12bcphoto_05.jpg" title="">
                                            <img src="images/zoom.png" alt=""/></a>
                                    </div>
                                </div>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <div class="portfolio">
                                    <img src="admin/image/43c9157e9891dfe292fadb1d4b8e12bcphoto_05.jpg" alt=""/>
                                    <div class="hover">
                                        <a data-rel="prettyPhoto" href="admin/image/8d7b5a6c704390a15ba82c76520ec306photo_06.jpg" title="">
                                            <img src="images/zoom.png" alt=""/></a>
                                    </div>
                                </div>
                            </li>     
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php require 'footer.php'; ?>
