<?php require 'header.php'; ?>
<section>
    <div class="block remove-gap gray">
        <section>
            <div class="block gray half-parallax blackish remove-bottom">
                <div style="background:url(images/parallax8.jpg);" class="parallax"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="page-title">
                                <span>Kindly get something</span>
                                <h1>ABOUT <span>Specialties</span></h1>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="block gray">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 column">
                            <div class="remove-ext">
                                <div class="about-video">
                                    <div class="about-detail">
                                        <h3>Something <span>is Special</span></h3>
                                        <p><br>Kindly note our specialties</b>

                                            <br>
                                            <br> ●	Ambience & Decoration traditional culture.
                                            <br> ●	Popular Bamboo beats orchetstra.
                                            <br> ●	LCD display to facilitate close-up view of garba players.
                                            <br> ●	Multicuisine food stalls.
                                            <br> ●	Seating arrangement for 20000 viewers.
                                            <br> ●	Daily attractive prizes.
                                            <br> ●	safe and secure environment.
                                            <br> ●	75000 sq feet Beatiful landscape open Lawn.
                                            <br>Adequate Parking arrangement for 2000 four-wheelers and 7000 two-wheelers.</p>
                                    </div><!-- Event Details -->
                                    <div class="about-img">
                                        <img src="images/resource/upcoming-event4.jpg" alt="" />
                                    </div><!-- Event Image -->
                                </div><!-- Upcoming Event -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<?php require 'footer.php'; ?>

