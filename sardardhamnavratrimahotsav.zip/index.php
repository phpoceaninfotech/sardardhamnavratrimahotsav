<?php require 'header.php'; ?>
<section>
    <div class="block remove-gap remove-bottom blackish">
        <div class="">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="gallery_kenburns">
                        <canvas id="kenburns">
                            <p>Your browser doesn't support canvas!</p>
                        </canvas>
                    </div><!-- KENBURNS GALLERY -->

                    <div class="kenburns-wrapper">
                        <div class="container">
                            <div class="kenburns-text">
                                <div class="text-slide">
                                    <div class="title-side">
                                        <img src="images/A2.png">
                                    </div>
                                    <!-- <h5>GARBA - GARBA - GARBA</h5> -->
                                    <!-- <p>The Sardardham in Garba. Founded in 1990. Expertise in garba and organising Navratri events</p> -->
                                </div><!-- Text Slide -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- Kenburn Effect Section -->

<section>
    <div class="block remove-gap gray" style="padding-top: 20px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="title">
                        <span></span>
                        <h2>SARDARDHAM <span>GARBA</span></h2>
                        <p>CELEBRATING THE NAVRATRI SEASON WITH SARDARDHAM GROUP.</p>
                    </div><!-- Title -->
                    <div class="remove-ext">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="speaker">
                                    <div>
                                        <img src="images/s1.png" alt="" width="70%" />
                                    </div>
                                </div><!-- Event Speaker -->
                            </div>

                            <div class="col-md-6">
                                <h1 style="padding-bottom:10PX; color: #2559A6;">The Garba dance!</h1>
                                <p>Navaratri is a festival in which God is adored as Mother. It is said that Shiva gave permission to Durga to see her mother for nine days in the year and this festival also remembers this visit. Families make an attempt to return home on these days, and leave on the tenth</p>
                                <p>Navaratri is a festival in which God is adored as Mother. It is said that Shiva gave permission to Durga to see her mother for nine days in the year and this festival also remembers this visit. Families make an attempt to return home on these days, and leave on the tenth</p>
                            </div>

                        </div>
                    </div> <!--remove-ext end -->
                </div>
            </div>
        </div>
    </div>
</section><!-- Event Speaker Section -->


<section>
    <div class="block gray half-parallax blackish">
        <div style="background:url(images/01.jpg);" class="parallax"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="parallax-title">
                        <h2>SARDARDHAM NAVRATRI<span> - 2023</span></h2>
                        <h5>BOOK The Pass And Enjoy Garba!</h5>
                        <p>Contact Sardardham Group, Nr. Mavdi Chowk, 150 Feet ring road, Rajkot - 360004</p>
                    </div>

                    <div class="remove-ext offers">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="offer">
                                    <div class="offer-img"><img src="images/resource/offer1.jpg" alt="" /></div>
                                    <div class="offer-desc">
                                        <div class="offer-inner">
                                            <h3>COUPLE PASS</h3>
                                            <h5>1200 Rs. <span>/PER HEAD</span></h5>
                                            <p>View or purchase discounted Pass and enjoy Garba.</p>
                                            <a href="pass.php" title="">Contact</a>
                                        </div>
                                    </div>
                                </div><!-- Offer -->
                            </div>
                            <div class="col-md-4">
                                <div class="offer">
                                    <div class="offer-img"><img src="images/resource/offer2.jpg" alt="" /></div>
                                    <div class="offer-desc">
                                        <div class="offer-inner">
                                            <h3>FEMALE PASS</h3>
                                            <h5>1000 Rs. <span>/PER HEAD</span></h5>
                                            <p>View or purchase discounted Pass and enjoy Garba.</p>
                                            <a href="pass.php" title="">Contact</a>
                                        </div>
                                    </div>
                                </div><!-- Offer -->
                            </div>
                            <div class="col-md-4">
                                <div class="offer">
                                    <div class="offer-img"><img src="images/resource/offer3.jpg" alt="" /></div>
                                    <div class="offer-desc">
                                        <div class="offer-inner">
                                            <h3>BECOME SPONSOR</h3>
                                            <h5>8+ <span> CATEGORIES</span></h5>
                                            <p>Different sponsorship levels have been designed according to individual's needs.</p>
                                            <a href="sponsorships.php" title="">Become SPONSOR</a>
                                        </div>
                                    </div>
                                </div><!-- Offer -->
                            </div>
                        </div>
                    </div><!-- Offers -->
                </div>
            </div>
        </div>
    </div>
</section><!--Offers Section-->


<section>
    <div class="block blackish">
        <div style="background:url(images/02.jpg);" class="parallax"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-5 column">
                    <div class="parallax-text">
                        <span></span>
                        <h2>Prince <span>Princess</span></h2>
                        <p>your dream to become PRINCE and PRINCESS in famous GARBA events of Sardar Dham Navratri Mahotsav 2023!</p>
                        <h2>King <span>Queen</span></h2>
                        <p>your dream to become KING and QUEEN in famous GARBA events of Sardar Dham Navratri Mahotsav 2023!</p>
                        <a class="button" href="#" title="">BOOK NOW</a>
                    </div><!-- Parallax Text -->
                </div>
                <div class="col-md-offset-1 col-md-6 column">
                    <div class="fancy-services">
                        <div class="fancy-service">
                            <img src="images/resource/offer1.jpg" alt="" />
                            <div class="fancy-detail">
                                <span><img src="images/resource/fancy-service1.png" alt="" /></span>
                                <h3>Prince</h3>
                                <h6>2023</h6>
                                <p>Chance to become King.</p>
                            </div>
                        </div><!-- Fancy Service -->
                        <div class="fancy-service">
                            <img src="images/resource/offer2.jpg" alt="" />
                            <div class="fancy-detail">
                                <span><img src="images/resource/fancy-service2.png" alt="" /></span>
                                <h3>Princess</h3>
                                <h6>2023</h6>
                                <p>Chance to become Queen.</p>
                            </div>
                        </div><!-- Fancy Service -->
                        <div class="fancy-service">
                            <img src="images/resource/offer1.jpg" alt="" />
                            <div class="fancy-detail">
                                <span><img src="images/resource/fancy-service3.png" alt="" /></span>
                                <h3>King</h3>
                                <h6>2023</h6>
                                <p>King of 2018.</p>
                            </div>
                        </div><!-- Fancy Service -->
                        <div class="fancy-service">
                            <img src="images/resource/offer2.jpg" alt="" />
                            <div class="fancy-detail">
                                <span><img src="images/resource/fancy-service4.png" alt="" /></span>
                                <h3>Queen</h3>
                                <h6>2023</h6>
                                <p>Queen of 2023.</p>
                            </div>
                        </div><!-- Fancy Service -->
                    </div><!-- Fancy Services Carousel -->
                </div>
            </div>
        </div>
    </div>
</section><!-- Upcoming Event Section -->


<section>
    <div class="block remove-gap gray" style="padding-top: 20px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="title">
                        <span></span>
                        <h2>Our <span>Specialties</span></h2>
                        <p>These are Specialties of SARDARDHAM NAVRATRI .</p>
                    </div><!-- Title -->
                    <div class="snaps-gallery">
                        <div class="col-md-6">
                            <div class="snap style1">
                                <div class="gallery-img">
                                    <img src="images/04.jpg" alt="" />
                                    <a data-rel="prettyPhoto" href="images/04.jpg" title=""><i class="fa fa-search"></i></a>
                                </div>
                                <div class="snap-detail">
                                    <h4>Happy Environment</h4>
                                    <p>we provide free, secure and happy environment where people enjoy garba. </p>
                                </div>
                            </div><!-- Snap Style 1 -->
                            <div class="snap style2">
                                <div class="gallery-img">
                                    <img src="images/09.jpg" alt="" />
                                    <a data-rel="prettyPhoto" href="images/09.jpg" title=""><i class="fa fa-search"></i></a>
                                </div>
                                <div class="snap-detail">
                                    <h4>Garba</h4>
                                    <p>May the energy of Garba bless you with happiness and peace </p>
                                </div>
                            </div><!-- Snap Style 2 -->
                        </div>
                        <div class="col-md-6">
                            <div class="snap style1">
                                <div class="snap-detail">
                                    <h4>Multicuisine Food</h4>
                                    <p>There are varied cuisines stalls within environment.</p>
                                </div>
                                <div class="gallery-img">
                                    <img src="images/resource/snap3.jpg" alt="" />
                                    <a data-rel="prettyPhoto" href="images/resource/snap3.jpg" title=""><i class="fa fa-search"></i></a>
                                </div>
                            </div><!-- Snap Style 2 -->
                            <div class="snap style2">
                                <div class="snap-detail">
                                    <h4>Live Telecast</h4>
                                    <p>LCD displays inside venue and live telecast provision.</p>
                                </div>
                                <div class="gallery-img">
                                    <img src="images/08.jpeg" alt="" />
                                    <a data-rel="prettyPhoto" href="images/08.jpeg" title=""><i class="fa fa-search"></i></a>
                                </div>
                            </div><!-- Snap Style 1 -->
                        </div>
                    </div><!-- Snaps Gallery -->
                </div>
            </div>
        </div>
    </div>
</section><!-- Snaps From Show -->


<!--<section>
    <div class="block blackish">
        <div style="background:url(images/03.jpg);" class="parallax"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="video-parallax">
                        <h3>Khelo  <span>Dandiya</span></h3>
                        <span>@ SARDARDHAM Group</span>
                        <p>SARDARDHAM Group With Live Telecast, orchestra and Beautiful landspace open Lawn and perfect venue.</p>
                        <a href="https://www.youtube.com/watch?v=zTRSx47KwyQ"  data-rel="prettyPhoto" title=""><i class="fa fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> Video Parallax -->
<!--<section>
    <div class="block remove-gap gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="title">
                        <span></span>
                        <h2>Privious <span>SPONSORS</span></h2>
                        <p>Contact 99251 55543 to become sponsor.</p>
                    </div><!-- Title 
                    <div class="event-sponsors remove-ext">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_01.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_02.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_03.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_04.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_05.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_06.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_07.jpg" alt="" /></div>
                            </div>
                            <div class="col-md-3">
                                <div class="sponsor"><img src="images/resource/sponser_08.jpg" alt="" /></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> Event Sponsors -->

<?php require 'footer.php'; ?>




