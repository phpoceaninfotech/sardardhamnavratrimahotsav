<?php require 'header.php'; ?>
<section>
    <div class="block remove-gap gray">
        <section>
            <div class="block gray half-parallax blackish remove-bottom">
                <div style="background:url(images/parallax8.jpg);" class="parallax"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="page-title">
                                <span>WE PROVIDE AWESOME DEALS</span>
                                <h1>Book <span>Pass</span></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="block gray">
                <div class="container">
                    <div class="row">
                        <form action="#" method="post" enctype="multipart/form-data">
                        <div class="col-md-6 col-md-push-3 column" style="border-radius: 5px;padding: 15px;background-image:url('images/pattern.jpg'); background-repeat: repeat">
                            <div class="form-group">
                                <label style="color: white">Enter Name</label>
                                <input type="text" class="form-control" name="name" placeholder="Enter Your Name" required>
                            </div>
                            <div class="row">
                                <div class=" col-md-6 form-group">
                                    <label style="color: white">Mobile No.</label>
                                    <input type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile No." required>
                                </div>
                                <div class=" col-md-6 form-group">
                                    <label style="color: white">City</label>
                                    <input type="text" class="form-control" name="city" placeholder="Enter Your City" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label style="color: white">Select Your Pass</label>
                                <select class="form-control" name="gender" onchange="showfield(this.options[this.selectedIndex].value)">
                                    <option>Select</option>
                                    <option value="Couple">Couple Pass</option>
                                    <option value="Male" >Male Pass</option>
                                    <option value="Female">Female Pass</option>
                                </select>
                            </div>

                            <div id="div1"></div>

                            <div class="form-group row" style="padding-left: 300px;">
                                <label class="col-sm-2 col-form-label"></label>
                                <div class="col-sm-10">
                                    <input type="submit" name="payment" id="payment" class="btn btn btn-success" value="Payment Now">
                                    <input type="submit" name="btn_submit" id="btn_submit" class="btn btn btn-primary" value="Submit">
                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<?php require 'footer.php'; ?>


<script type="text/javascript">
function showfield(name){
    if(name=='Couple')document.getElementById('div1').innerHTML = 
    '<div class="row"><div class="col-md-6 form-group"><label style="color: white">Male Aadhar Card No.</label><input type="text" name="male_aadhar" class="form-control" placeholder="Enter Male Aadhar Card No." value=""></div><div class="col-md-6 form-group"><label style="color: white">Female Aadhar Card No.</label><input type="text" name="male_aadhar" class="form-control" placeholder="Enter Male Aadhar Card No." value=""></div></div><div class="row"><div class="col-md-6 form-group"><label style="color: white">Male Aadhar Image</label><i style="color: red">*fornt and back*</i><input type="file" name="male_aadhar" class="form-control"  value=""></div><div class="col-md-6 form-group"><label style="color: white">Female Aadhar Image</label><i style="color: red">*fornt and back*</i><input type="file" name="male_aadhar" class="form-control" value=""></div></div><div class="row"><div class="col-md-6 form-group"><label style="color: white">Male Photo</label><input type="file" name="male_aadhar" class="form-control"  value=""></div><div class="col-md-6 form-group"><label style="color: white">Female Photo</label><input type="file" name="male_aadhar" class="form-control" value=""></div></div>';

  else if(name=='Male' )document.getElementById('div1').innerHTML = 
    '<div class="row"><div class="col-md-6 form-group"><label style="color: white">Male Aadhar Card No.</label><input type="text" name="male_aadhar" class="form-control" placeholder="Enter Male Aadhar Card No." value=""></div><div class="col-md-6 form-group"><label style="color: white">Male Aadhar Image</label><i style="color: red">*fornt and back*</i><input type="file" name="male_aadhar" class="form-control" value=""></div><div class="col-md-6 form-group"><label style="color: white">Male Photo</label><input type="file" name="male_aadhar" class="form-control"  value=""></div></div>';
  else 
    document.getElementById('div1').innerHTML=
    '<div class="row"><div class="col-md-6 form-group"><label style="color: white">Female Aadhar Card No.</label><input type="text" name="male_aadhar" class="form-control" placeholder="Enter Male Aadhar Card No." value=""></div><div class="col-md-6 form-group"><label style="color: white">Female Aadhar Image</label><i style="color: red">*fornt and back*</i><input type="file" name="male_aadhar" class="form-control" value=""></div><div class="col-md-6 form-group"><label style="color: white">Male Photo</label><input type="file" name="male_aadhar" class="form-control"  value=""></div></div>';
}
</script>
