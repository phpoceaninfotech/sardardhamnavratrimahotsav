<?php require 'header.php'; ?>
<section>
    <div class="block gray half-parallax blackish remove-bottom">
        <div style="background:url(images/parallax8.jpg);" class="parallax"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8">
                    <div class="page-title">
                        <h1>Video <span>Gallery</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="block gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12 column">
                    <div class="row">
                        <ul id="Grid">
                            <li class="mix category_1 col-md-4">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/8Ua2xoc6tRk"style="height:100%; width:100%" height="100%" width="100%" allowfullscreen>
                                </iframe>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/8Ua2xoc6tRk"style="height:100%; width:100%" height="100%" width="100%" allowfullscreen>
                                </iframe>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/8Ua2xoc6tRk"style="height:100%; width:100%" height="100%" width="100%" allowfullscreen>
                                </iframe>
                            </li>
                            <li class="mix category_1 col-md-4">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/8Ua2xoc6tRk" style="height:100%;width:100%" height="100%" width="100%" allowfullscreen>
                                </iframe>
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php require 'footer.php'; ?>