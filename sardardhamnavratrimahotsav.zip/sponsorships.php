<?php require 'header.php'; ?>
<section>
    <div class="block remove-gap gray">
        <section>
            <div class="block gray half-parallax blackish remove-bottom">
                <div style="background:url(images/parallax8.jpg);" class="parallax"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="page-title">
                                <h1>EVENT <span>SPONSORSHIPS</span></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="block gray">
                <div class="container" >
                    <div class="row" >
                        <div class="col-md-12 column">

                            <div class="schedule-tabs">

                                <div class="tab-content" id="myTabContent" style="min-height:550px;">
                                    <div id="month1" class="tab-pane fade active in">

                                        <div class="tab-content" id="myTabContent2" >
                                            <div id="month1-day1" class="tab-pane fade active in" >

                                                <div class="event">
                                                    <div class="event-image"><img src="images/resource/event1.jpg" alt="" /></div>
                                                    <h3><a href="#" title="">TITLE SPONSORSHIP </a></h3>
                                                    <p> ●	Title sponsorship logo will be displayed before Parth Raj Club presents ‘Bamboo Beats GarbaMahotsav 2019 
                                                        <br>
                                                        ●	Display at main stage back drop
                                                        <br>
                                                        ●	Size 20x10 – 3 hoardings, 10x10- 1 hoardings in selfie zone
                                                        <br>
                                                        ●	Logo in hoarding advertisement of event<br>
                                                        ●	Logo in daily pass
                                                        <br>
                                                        ●	Announcement throughout the event
                                                        <br>
                                                        ●	LED Flashes
                                                        <br>
                                                        ●	Social Media coverage in daily Navaratri videos for 10 days
                                                        <br>
                                                        ●	Website advertisement for 10 days.
                                                        <br>
                                                    </p>
                                                    <div class="event-bottom">
                                                        <div class="social">
                                                            <a href="#" title=""><i class="fa fa-facebook-square"></i></a>
                                                            <a href="#" title=""><i class="fa fa-twitter-square"></i></a>
                                                            <a href="#" title=""><i class="fa fa-linkedin-square"></i></a>
                                                            <a href="#" title=""><i class="fa fa-google-plus-square"></i></a>
                                                        </div>
                                                        <ul>
                                                            <li><img src="images/event-icon.png" alt="" /> Price: 15,00,000 Rs.</li>
                                                            <li><img src="images/event-icon2.png" alt="" /> Contact: 99251 55543</li>
                                                        </ul>
                                                    </div>
                                                </div><!-- event -->

                                            </div>
                                       </div>
                                    </div><!-- month1 -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--block gray -->
        </section>
    </div>
</section>
<?php require 'footer.php'; ?>

