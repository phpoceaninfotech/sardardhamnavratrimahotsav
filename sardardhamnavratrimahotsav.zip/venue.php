<?php require 'header.php'; ?>
<section>
    <div class="block remove-gap gray">
        <section>
            <div class="block gray half-parallax blackish remove-bottom">
                <div style="background:url(images/parallax8.jpg);" class="parallax"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8">
                            <div class="page-title">
                                <span>WE PROVIDE AWESOME VENUE</span>
                                <h1>ABOUT <span>Venue</span></h1>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="block gray">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 column">
                            <div class="remove-ext">
                                <div class="about-video">
                                    <div class="about-detail">
                                        <h3>Safe and Secure <span> Environment</span></h3>
                                        <p>

                                            <br>Seating arrangement of stadium type and coporate boxs for more than 20,000 viewers. Multicusine food stalls of more than 30 varied cuisines. Beautiful landscape open Lawn and perfect venue.
                                            <br><br><b>Rajhans Party  Plot.</b>
                                        <br> Near Pradyuman Green City
                                        <br> Vrindavan Society Main Road
                                        <br> Kalawad Road
                                        <br> Rajkot - 360001</p>
                                    </div><!-- Event Details -->
                                    <div class="about-img">
                                        <img src="images/resource/upcoming-event3.jpg" alt="" />
                                    </div><!-- Event Image -->
                                </div><!-- Upcoming Event -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<?php require 'footer.php'; ?>